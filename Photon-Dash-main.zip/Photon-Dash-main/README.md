# Photon-Dash
## Description
A game where you control a photon and your aim is to get to the finish line as soon as possible! Bounce off mirrors to change your direction and travel through glass and water to alter your speed on each level all while strategically avoid dying from the deadly void.

## Tech stack:
Javascript, HTML, CSS

## How to run:
