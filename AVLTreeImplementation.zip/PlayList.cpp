// Alexander Potiagalov (301586871)
// CMPT 225
// 09/18/2024

#include "PlayList.h"

// PlayList method implementations:

// Default Constructor
PlayList::PlayList() : head(nullptr), playListSize(0) {}

// Deep copy constructor
PlayList::PlayList(const PlayList& pl) {
    
    if (pl.head == nullptr) {
        head = nullptr;  
        playListSize = 0;
    } else {       
        head = new PlayListNode(pl.head->song);
        playListSize++;

        PlayListNode* original = pl.head->next;
        PlayListNode* copy = head;

        while (original != nullptr) {
            copy->next = new PlayListNode(original->song);  
            original = original->next;  
            copy = copy->next;  
            playListSize++;
        }
    }
}

// Destructor
PlayList::~PlayList() {
    
    PlayListNode* temp = head;
    while(head != nullptr){
        head = head->next;
        delete temp;
        temp = head;
    }
    head = nullptr;
    playListSize = 0;
}

// Overloaded assignment operator
PlayList& PlayList::operator=(const PlayList & pl){

    if (this != &pl) {      
        PlayListNode* temp = head;
        while (head != nullptr) {
            head = head->next;
            delete temp;
            temp = head;
        }
        head = nullptr;
        playListSize = 0;

        if (pl.head == nullptr) {
            head = nullptr;  
            playListSize = 0;
        } else {
            head = new PlayListNode(pl.head->song);
            playListSize++;
            PlayListNode* original = pl.head->next;
            PlayListNode* copy = head;
            while (original != nullptr) {
                copy->next = new PlayListNode(original->song);  
                original = original->next;  
                copy = copy->next;  
                playListSize++;
            }
        }
    }
    return *this;  
}


// Insert
void PlayList::insert(Song sng, unsigned int pos){
    
    PlayListNode* newNode = new PlayListNode(sng);
    if (pos == 0 || head == nullptr){
        newNode->next = head;
        head = newNode;
    } else { 
        PlayListNode* current = head;
        PlayListNode* prev = nullptr;
        for (int i = 0; i < pos; i++){
            prev = current;
            current = current->next;
        }
        prev->next = newNode;
        newNode->next = current;
    }
    playListSize++;
}

// Get
Song PlayList::get(unsigned int pos) const {
    
    PlayListNode* current = head;
    for (int i = 0; i < pos; i++){
        current = current->next;
    }
    return current->song;
}

// Remove
Song PlayList::remove(unsigned int pos) {

    PlayListNode* current = head;
    PlayListNode* prev = nullptr;
    if (pos == 0) {  
        Song removedSong = current->song;  
        head = current->next;  
        delete current;  
        playListSize--;  
        return removedSong;
    }
    for (int i = 0; i < pos; i++) {  
        prev = current;
        current = current->next;
    }
    Song removedSong = current->song;  
    prev->next = current->next;  
    delete current;  
    playListSize--;  
    
    return removedSong;  
}

// Swap
void PlayList::swap(unsigned int pos1, unsigned int pos2) {

    if (pos1 == pos2) return;

    PlayListNode* prev1 = nullptr;
    PlayListNode* prev2 = nullptr;
    PlayListNode* node1 = head;
    PlayListNode* node2 = head;

    for (int i = 0; i < pos1 && node1 != nullptr; i++) {
        prev1 = node1;
        node1 = node1->next;
    }

    for (int i = 0; i < pos2 && node2 != nullptr; i++) {
        prev2 = node2;
        node2 = node2->next;
    }

    if (node1 == nullptr || node2 == nullptr) return;

    // Connecting the prev pointers
    if (prev1 != nullptr) {
        prev1->next = node2; 
    } else {
        head = node2; 
    }

    if (prev2 != nullptr) {
        prev2->next = node1; 
    } else {
        head = node1; 
    }

    PlayListNode* temp = node1->next;
    node1->next = node2->next;
    node2->next = temp;
}

unsigned int PlayList::size() const {
    return playListSize;
}